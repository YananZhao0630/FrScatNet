%% SCN (the conventional scattering network)
%% The features obtained by wavelet_transform_2d 
%% load the database
clear; close all;
% NOTE : the following line must be modified with the path to the
% database in YOUR system.
path_to_db = 'D:\ɢ������\datasets\������������';
% src �� classes, files, objects
src = kthtips_src(path_to_db);
db_name = 'dataset';



% 
% %% ---------------------------------------------------
% %% ----------------- trans_scatt ---------------------
% %% ---------------------------------------------------
% 
% 
% %% compute scattering of all images in the database
% 
Nim = 200;
filt_opt.filter_type = 'morlet';  
filt_opt.J = 4;
filt_opt.L = 8;
scat_opt.M = 2;
%% based on the close relationship between fractional wavelet scattering network and conventional network;
%% when alpha1 = a*pi/2 with a = 1, and alpha2 = b*pi/2 with b = 1;
%% fractional wavelet scattering network reduced to conventional scattering network
a = 1; b = 1;
[Wop,filters] = wavelet_factory_2d([Nim Nim], filt_opt, scat_opt,a,b);

% % a function handle that
% %   - read the image
% %   - resize it to 200x200
% %   - compute its scattering
% 
% % to compute the scarttering ecoffients of the input filename
% % and the output is the function of fileme
% % which will be calculated later when transformed into x in the filename
fun = @(filename)(scat(imresize_notoolbox(imreadBW(filename),[200 200]), Wop));
% 
% % compute all scattering
% % (500 seconds on a 2.4 Ghz Intel Core i7)
trans_scatt_all = srcfun(fun, src);
% %%
% % a function handle that
% %   - format the scattering in a 3d matrix
% %   - remove order 0
% %   - remove margins along dimension 2 and 3
% %   - average accross position
% % (10 seconds on a 2.4 Ghz Intel Core i7)

fun = @(Sx)(sum(sum(remove_margin(format_scat(Sx),[1,0,1,1,1,1]),2),3));
trans_scatt = cellfun_monitor(fun ,trans_scatt_all);
% 
% 
% % % format the database of feature
db = cellsrc2db(trans_scatt, src);
% % 
% % %% classification
grid_train = [2,5,8,10,15,20,50,100,200]; % number of training for classification
nb_split = 100; % number of split for classification
rsds_classif(db, db_name, 'SCN', grid_train, nb_split);