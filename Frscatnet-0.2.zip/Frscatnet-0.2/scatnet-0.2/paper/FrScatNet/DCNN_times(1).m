%% Conv_net for image classification
%% Reference is as follows 
%% https://ww2.mathworks.cn/help/deeplearning/ug/create-simple-deep-learning-network-for-classification.html;jsessionid=17dee8e5cdace0e531f242df7f12
clear all; close all; 
%% the path of the database set by users
digitDatasetPath = fullfile('D:','ɢ������','datasets','�����������');
imds = imageDatastore(digitDatasetPath, 'IncludeSubfolders',true,'LabelSource','foldernames');
labelCount = countEachLabel(imds);
% G = imreadBW(imds.Files{1});
% G1 = imread(imds.Files{1});
% img = readimage(imds,1);
% M = imresize_notoolbox(imreadBW(imds.Files{1}),[200 200]);
img = readimage(imds,1);
size(img)
grid_train = [2,5,8,10,15,20,50,100,200];
splittimes = 100;
for i_split = 1: splittimes
for i_train = 1:numel(grid_train)
    numTrainFiles = grid_train(i_train);
    [imdsTrain,imdsValidation] = splitEachLabel(imds,numTrainFiles,'randomize');
    layers = [
    imageInputLayer([200 200 3])
    
    convolution2dLayer(3,5,'Padding','same')
    batchNormalizationLayer
    reluLayer
    
    maxPooling2dLayer(2,'Stride',2)
    
    convolution2dLayer(3,10,'Padding','same')
    batchNormalizationLayer
    reluLayer
    
    maxPooling2dLayer(2,'Stride',2)
    
    convolution2dLayer(3,20,'Padding','same')
    batchNormalizationLayer
    reluLayer
    
    fullyConnectedLayer(9)
    softmaxLayer
    classificationLayer];
options = trainingOptions('sgdm', ...
    'InitialLearnRate',0.005, ...
    'MaxEpochs',15, ...
    'Shuffle','every-epoch', ...
    'ValidationData',imdsValidation, ...
    'ValidationFrequency',30, ...
    'MiniBatchSize',64, ...
    'Verbose',false);
  % 'Plots','training-progress'
net = trainNetwork(imdsTrain,layers,options);
YPred = classify(net,imdsValidation);
YValidation = imdsValidation.Labels;
accuracy = sum(YPred == YValidation)/numel(YValidation);
error(i_split,i_train) = 1 - accuracy;
end
end
perf = mean(error);
perf_std = std(error);
for i_train = 1:numel(grid_train)
    fprintf('database classification error with %2d training : %.2f += %.2f \n', ...
        grid_train(i_train), perf(i_train), perf_std(i_train));
end
% [imdsTrain,imdsValidation] = splitEachLabel(imds,numTrainFiles,'randomize');
% layers = [
%     imageInputLayer([200 200 3])
%     
%     convolution2dLayer(3,5,'Padding','same')
%     batchNormalizationLayer
%     reluLayer
%     
%     maxPooling2dLayer(2,'Stride',2)
%     
%     convolution2dLayer(3,10,'Padding','same')
%     batchNormalizationLayer
%     reluLayer
%     
%     maxPooling2dLayer(2,'Stride',2)
%     
%     convolution2dLayer(3,20,'Padding','same')
%     batchNormalizationLayer
%     reluLayer
%     
%     fullyConnectedLayer(9)
%     softmaxLayer
%     classificationLayer];
% options = trainingOptions('sgdm', ...
%     'InitialLearnRate',0.005, ...
%     'MaxEpochs',15, ...
%     'Shuffle','every-epoch', ...
%     'ValidationData',imdsValidation, ...
%     'ValidationFrequency',30, ...
%     'MiniBatchSize',64, ...
%     'Verbose',false, ...
%     'Plots','training-progress');
% net = trainNetwork(imdsTrain,layers,options);
% YPred = classify(net,imdsValidation);
% YValidation = imdsValidation.Labels;
% accuracy = sum(YPred == YValidation)/numel(YValidation)