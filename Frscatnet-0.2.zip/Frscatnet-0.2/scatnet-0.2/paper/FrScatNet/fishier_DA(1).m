function FDA=fishier_DA(X,Y)
%YΪ1��N��NΪ�����
m=zeros(1,max(Y(:)));
for i=1:max(Y(:))
   m(i)=mean(X(find(Y==i))); 
end
X_zero_m=zeros(size(X));
for i=1:size(X,2)
    X_zero_m(:,i)=X(:,i)-m(Y(i));
end
X_inter_class=X_zero_m*X_zero_m'/size(X,2);
M_intra=mean(m);
m_temp=m-M_intra;
X_intra_class=m_temp*m_temp';
FDA=sum(diag(X_inter_class))/sum(diag(X_intra_class))/max(Y(:));
end