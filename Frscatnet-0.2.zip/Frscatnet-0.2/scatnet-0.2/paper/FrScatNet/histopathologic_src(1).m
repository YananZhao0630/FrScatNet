% UIUC_SRC Creates a source for the UIUC Texture dataset
%
% Usage
%    src = UIUC_SRC(directory)
%
% Input
%    directory: The directory containing the UIUC Texture dataset.
%
% Output
%    src: The UIUC source.
%
% Note
%	The dataset is available at http://www-cvr.ai.uiuc.edu/ponce_grp/data/


function src = histopathologic_src(directory)
	if (nargin<1)
%          directory = 'E:\С��ɢ������\scatnet-0.2\datasets\IM'; % PUT DEFAULT DIRECTORY HERE
        directory = 'D:\С��ɢ������\datasets'; % PUT DEFAULT DIRECTORY HERE
	end
	src = create_src(directory, @uiuc_extract_objects_fun);%src = create_src(directory, @uiuc_extract_objects_fun);
end

function [objects, classes] = uiuc_extract_objects_fun(file)
	objects.u1 = [1,1];
% 	objects.u2 = [32,32];
    x = imreadBW(file);
	[h, w] = size(x);
	objects.u2 = [h, w];
	path_str = fileparts(file);
	path_parts = regexp(path_str, filesep, 'split');
	classes = {path_parts{end}};
end