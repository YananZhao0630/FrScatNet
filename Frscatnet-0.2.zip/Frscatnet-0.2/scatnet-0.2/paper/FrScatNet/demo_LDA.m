clear all; close all; clc; 
load db_feature_label
X = double(db.features);
labels = db.src.objects.class;

%X = [randn(10,2); randn(15,2) + 1.5];  Y = [zeros(10,1); ones(15,1)];
W = LDA(X,labels);
L = [ones(25,1) X] * W';
P = exp(L) ./ repmat(sum(exp(L),2),[1 2]);