clc; clear all; close all;
load db_feature_label
n_class = numel(db.src.classes); % the number of class
n_images = numel(db.src.files);  % the number of images(total samples)
n_per_class = n_images/n_class;  % the number of images in per class
feature_matrix = double(db.features);

n_train = 10;
prop = n_train/n_per_class;
[train_set, test_set] = create_partition(db.src, prop);
train_samples = double(db.features(:,train_set));
        for i = 1:numel(train_set)
        train_classes(i,1) = db.src.objects(train_set(i)).class;
        end
        for i = 1:numel(test_set)
        test_classes(i,1)= db.src.objects(test_set(i)).class;
        end
test_samples = double(db.features(:,test_set));
[coeffMatrix,scoreTrain,eigval,score,meanValue]  = myPCA(train_samples);
