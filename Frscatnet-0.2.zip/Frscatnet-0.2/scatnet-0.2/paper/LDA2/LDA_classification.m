clc; clear all; close all;
load db_feature_label
n_class = numel(db.src.classes); % the number of class
n_images = numel(db.src.files);  % the number of images(total samples)
n_per_class = n_images/n_class;  % the number of images in per class
grid_train = [10]; % the number of training for classification
error = [];
train_classes = [];
test_classes = [];
for i_train = 1:numel(grid_train)
    n_train = grid_train(i_train); % training sample in each class
    prop = n_train/n_per_class;
    [train_set, test_set] = create_partition(db.src, prop);
    train_opt.dim = n_train;
    train_samples = (double(db.features(:,train_set)))';
        for i = 1:numel(train_set)
        train_classes(i,1) = db.src.objects(train_set(i)).class;
        end
        for i = 1:numel(test_set)
        test_classes(i,1)= db.src.objects(test_set(i)).class;
        end
    test_samples = (double(db.features(:,test_set)))';
     [W,centers] = LDA(train_samples,train_classes);
     
    %[model,k,ClassLabel] = LDATraining(train_samples,train_classes);
    %target = LDATesting(test_samples,k,model,ClassLabel);
    error(i_train)= classif_err(target, test_set, db.src);
end
for i = 1:numel(error)
    fprintf('%2d training samples with error rate: %.2f\n',grid_train(i), error(i));
end