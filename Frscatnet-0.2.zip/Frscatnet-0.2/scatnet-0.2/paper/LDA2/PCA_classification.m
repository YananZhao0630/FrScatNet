%% feature extraction and dimension reduction by PCA and LCA
%% The feature extraction is done by wavelet scattering network
%% Reference: 
clc; clear all; close all;
load db_feature_label
n_class = numel(db.src.classes); % the number of class
n_images = numel(db.src.files);  % the number of images(total samples)
n_per_class = n_images/n_class;  % the number of images in per class

% PCA classification --> affine_train
grid_train = [10,20,50,100]; % the number of training for classification
% nb_split = ; % number of split for classification ---
error = [];
for i_train = 1:numel(grid_train)
    n_train = grid_train(i_train); % training sample in each class
    prop = n_train/n_per_class;
    [train_set, test_set] = create_partition(db.src, prop);
    train_opt.dim = n_train/10;
    model = affine_train(db, train_set, train_opt);
    labels = affine_test(db, model, test_set);
    error(i_train) = classif_err(labels, test_set, db.src);
end
for i = 1:numel(error)
    fprintf('%2d training samples with error rate: %.2f\n',grid_train(i), error(i));
end