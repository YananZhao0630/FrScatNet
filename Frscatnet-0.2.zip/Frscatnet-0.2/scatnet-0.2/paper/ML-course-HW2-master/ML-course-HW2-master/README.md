# ML-course-HW2
Linear Discriminant Analysis (LDA) and Principal Component Analysis (PCA)
