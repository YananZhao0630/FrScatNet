To reproducibility, one need to do some steps as following:
Step1: load addpath_scatnet.m
Step2: open file: paper/FrScatNet
In the FrScatNet, the results in Table III are calculated by
1.  FrScatNet （fractional scattering convolution network）--- PCA_classification_FRSCN.m
2.  SCN (conventional scattering convolution network)---PCA_classification_SCN.m
3. TFSCN (time-frequency scattering convolution network)---PCA_classification_TFSCN.m
4. DCNN---DCNN_times.m